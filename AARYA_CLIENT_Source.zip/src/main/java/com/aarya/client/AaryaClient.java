package com.aarya.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.Window;

public class AaryaClient implements ClientModInitializer {
    private int ticks;
    private int cpsWindowTicks;
    private int clicksThisWindow;
    private int cps;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ticks++;
            cpsWindowTicks++;
            if (cpsWindowTicks >= 20) {
                cps = clicksThisWindow;
                clicksThisWindow = 0;
                cpsWindowTicks = 0;
            }
        });

        // This starter HUD is intentionally small and uses public client APIs.
        // Exact API names can change between Minecraft/Fabric versions.
        HudRenderCallback.EVENT.register((DrawContext context, float tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client == null || client.getWindow() == null) return;

            Window window = client.getWindow();
            int x = 8;
            int y = 8;
            String title = "AARYA CLIENT";
            String fps = "FPS: " + client.getCurrentFps();
            String cpsText = "CPS: " + cps;

            context.drawText(client.textRenderer, title, x, y, 0x55FFFF, true);
            context.drawText(client.textRenderer, fps, x, y + 12, 0xFFFFFF, true);
            context.drawText(client.textRenderer, cpsText, x, y + 24, 0xFFFFFF, true);

            String keys = "";
            if (client.options.forwardKey.isPressed()) keys += "W ";
            if (client.options.leftKey.isPressed()) keys += "A ";
            if (client.options.backKey.isPressed()) keys += "S ";
            if (client.options.rightKey.isPressed()) keys += "D ";
            if (client.options.jumpKey.isPressed()) keys += "SPACE";
            context.drawText(client.textRenderer, "Keys: " + (keys.isEmpty() ? "-" : keys),
                    x, y + 36, 0xFFFFFF, true);
        });
    }
}
