AARYA CLIENT — STARTER SOURCE PROJECT

Yeh SOURCE PROJECT hai, ready-to-install JAR nahi.
Ismein basic client HUD ka starter code hai: AARYA naam, FPS, CPS display aur W/A/S/D/Space key display.

ZAROORI:
- Minecraft 26.3 aur Fabric ke exact versions launcher/Fabric ke official compatibility pages se verify karne honge.
- Is project ki dependency versions template ke roop mein rakhi gayi hain; ho sakta hai build se pehle unhe sahi versions se badalna pade.
- Android par sirf ZIP ko Minecraft ke mods folder mein daalne se yeh mod kaam nahi karega. Pehle computer ya compatible Gradle build environment mein compile karke JAR banana hota hai.
- Yeh anti-cheat bypass, hidden cheating, KillAura/aimbot ya server par unfair advantage ke liye nahi bana hai.
- Agle version mein user ke bheje hue logo/design aur allowed utility modules add kiye ja sakte hain.

Project files:
- build.gradle / settings.gradle: build setup
- src/main/resources/fabric.mod.json: Fabric mod metadata
- src/main/java/com/aarya/client/AaryaClient.java: starter HUD code

Agar build error aaye, exact error text bhejna. Minecraft/Fabric versions ke hisaab se code/dependencies adjust karni pad sakti hain.
